﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KumAndGo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            panel1.Width += 3;

            if (panel1.Width >= 599)
            {
                this.Hide();
                timer1.Stop();
                MenuForm main = new MenuForm();
                main.Show();
            }
    }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
