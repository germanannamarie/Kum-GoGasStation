﻿namespace KumAndGo
{
    partial class MenuForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MenuForm));
            this.siticonePictureBox1 = new Siticone.Desktop.UI.WinForms.SiticonePictureBox();
            this.siticoneButton3 = new Siticone.Desktop.UI.WinForms.SiticoneButton();
            this.siticoneButton2 = new Siticone.Desktop.UI.WinForms.SiticoneButton();
            this.siticoneButton1 = new Siticone.Desktop.UI.WinForms.SiticoneButton();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.siticonePanel3 = new Siticone.Desktop.UI.WinForms.SiticonePanel();
            this.siticonePanel2 = new Siticone.Desktop.UI.WinForms.SiticonePanel();
            this.siticonePanel1 = new Siticone.Desktop.UI.WinForms.SiticonePanel();
            this.siticoneButton15 = new Siticone.Desktop.UI.WinForms.SiticoneButton();
            this.Clear = new Siticone.Desktop.UI.WinForms.SiticoneButton();
            this.siticoneButton10 = new Siticone.Desktop.UI.WinForms.SiticoneButton();
            this.nine = new Siticone.Desktop.UI.WinForms.SiticoneButton();
            this.eight = new Siticone.Desktop.UI.WinForms.SiticoneButton();
            this.seven = new Siticone.Desktop.UI.WinForms.SiticoneButton();
            this.six = new Siticone.Desktop.UI.WinForms.SiticoneButton();
            this.five = new Siticone.Desktop.UI.WinForms.SiticoneButton();
            this.four = new Siticone.Desktop.UI.WinForms.SiticoneButton();
            this.three = new Siticone.Desktop.UI.WinForms.SiticoneButton();
            this.two = new Siticone.Desktop.UI.WinForms.SiticoneButton();
            this.one = new Siticone.Desktop.UI.WinForms.SiticoneButton();
            this.label5 = new System.Windows.Forms.Label();
            this.AmountText = new Siticone.Desktop.UI.WinForms.SiticoneTextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.siticoneHtmlLabel2 = new Siticone.Desktop.UI.WinForms.SiticoneHtmlLabel();
            this.siticonePictureBox2 = new Siticone.Desktop.UI.WinForms.SiticonePictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.siticonePictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.siticonePictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // siticonePictureBox1
            // 
            this.siticonePictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.siticonePictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("siticonePictureBox1.Image")));
            this.siticonePictureBox1.ImageRotate = 0F;
            this.siticonePictureBox1.Location = new System.Drawing.Point(94, 10);
            this.siticonePictureBox1.Name = "siticonePictureBox1";
            this.siticonePictureBox1.Size = new System.Drawing.Size(86, 92);
            this.siticonePictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.siticonePictureBox1.TabIndex = 28;
            this.siticonePictureBox1.TabStop = false;
            this.siticonePictureBox1.UseTransparentBackground = true;
            // 
            // siticoneButton3
            // 
            this.siticoneButton3.BorderRadius = 15;
            this.siticoneButton3.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.siticoneButton3.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.siticoneButton3.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.siticoneButton3.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.siticoneButton3.FillColor = System.Drawing.Color.DarkOrange;
            this.siticoneButton3.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.siticoneButton3.ForeColor = System.Drawing.Color.White;
            this.siticoneButton3.Location = new System.Drawing.Point(461, 378);
            this.siticoneButton3.Name = "siticoneButton3";
            this.siticoneButton3.Size = new System.Drawing.Size(91, 32);
            this.siticoneButton3.TabIndex = 27;
            this.siticoneButton3.Text = "B U Y";
            this.siticoneButton3.Click += new System.EventHandler(this.siticoneButton3_Click);
            // 
            // siticoneButton2
            // 
            this.siticoneButton2.BorderRadius = 15;
            this.siticoneButton2.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.siticoneButton2.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.siticoneButton2.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.siticoneButton2.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.siticoneButton2.FillColor = System.Drawing.Color.RoyalBlue;
            this.siticoneButton2.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.siticoneButton2.ForeColor = System.Drawing.Color.White;
            this.siticoneButton2.Location = new System.Drawing.Point(256, 378);
            this.siticoneButton2.Name = "siticoneButton2";
            this.siticoneButton2.Size = new System.Drawing.Size(91, 32);
            this.siticoneButton2.TabIndex = 26;
            this.siticoneButton2.Text = "B U Y";
            this.siticoneButton2.Click += new System.EventHandler(this.siticoneButton2_Click);
            // 
            // siticoneButton1
            // 
            this.siticoneButton1.BorderRadius = 15;
            this.siticoneButton1.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.siticoneButton1.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.siticoneButton1.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.siticoneButton1.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.siticoneButton1.FillColor = System.Drawing.Color.OrangeRed;
            this.siticoneButton1.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.siticoneButton1.ForeColor = System.Drawing.Color.White;
            this.siticoneButton1.Location = new System.Drawing.Point(41, 378);
            this.siticoneButton1.Name = "siticoneButton1";
            this.siticoneButton1.Size = new System.Drawing.Size(91, 32);
            this.siticoneButton1.TabIndex = 25;
            this.siticoneButton1.Text = "B U Y";
            this.siticoneButton1.Click += new System.EventHandler(this.siticoneButton1_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(456, 350);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(105, 25);
            this.label4.TabIndex = 24;
            this.label4.Text = "D I E S E L";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(225, 350);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(161, 25);
            this.label3.TabIndex = 23;
            this.label3.Text = "U N L E A D E D";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(20, 350);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(141, 25);
            this.label2.TabIndex = 22;
            this.label2.Text = "P R E M I U M";
            // 
            // siticonePanel3
            // 
            this.siticonePanel3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("siticonePanel3.BackgroundImage")));
            this.siticonePanel3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.siticonePanel3.Location = new System.Drawing.Point(429, 109);
            this.siticonePanel3.Name = "siticonePanel3";
            this.siticonePanel3.Size = new System.Drawing.Size(158, 238);
            this.siticonePanel3.TabIndex = 20;
            // 
            // siticonePanel2
            // 
            this.siticonePanel2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("siticonePanel2.BackgroundImage")));
            this.siticonePanel2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.siticonePanel2.Location = new System.Drawing.Point(222, 109);
            this.siticonePanel2.Name = "siticonePanel2";
            this.siticonePanel2.Size = new System.Drawing.Size(158, 238);
            this.siticonePanel2.TabIndex = 21;
            // 
            // siticonePanel1
            // 
            this.siticonePanel1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("siticonePanel1.BackgroundImage")));
            this.siticonePanel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.siticonePanel1.Location = new System.Drawing.Point(12, 109);
            this.siticonePanel1.Name = "siticonePanel1";
            this.siticonePanel1.Size = new System.Drawing.Size(158, 238);
            this.siticonePanel1.TabIndex = 19;
            // 
            // siticoneButton15
            // 
            this.siticoneButton15.BorderRadius = 15;
            this.siticoneButton15.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.siticoneButton15.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.siticoneButton15.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.siticoneButton15.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.siticoneButton15.FillColor = System.Drawing.Color.SeaGreen;
            this.siticoneButton15.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.siticoneButton15.ForeColor = System.Drawing.Color.White;
            this.siticoneButton15.Location = new System.Drawing.Point(347, 599);
            this.siticoneButton15.Name = "siticoneButton15";
            this.siticoneButton15.Size = new System.Drawing.Size(85, 36);
            this.siticoneButton15.TabIndex = 148;
            this.siticoneButton15.Text = "ENTER";
            this.siticoneButton15.Click += new System.EventHandler(this.siticoneButton15_Click);
            // 
            // Clear
            // 
            this.Clear.BorderRadius = 15;
            this.Clear.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.Clear.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.Clear.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.Clear.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.Clear.FillColor = System.Drawing.Color.Goldenrod;
            this.Clear.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Clear.ForeColor = System.Drawing.Color.White;
            this.Clear.Location = new System.Drawing.Point(165, 599);
            this.Clear.Name = "Clear";
            this.Clear.Size = new System.Drawing.Size(85, 36);
            this.Clear.TabIndex = 147;
            this.Clear.Text = "CLEAR";
            this.Clear.Click += new System.EventHandler(this.Clear_Click);
            // 
            // siticoneButton10
            // 
            this.siticoneButton10.BorderRadius = 15;
            this.siticoneButton10.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.siticoneButton10.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.siticoneButton10.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.siticoneButton10.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.siticoneButton10.FillColor = System.Drawing.Color.SteelBlue;
            this.siticoneButton10.Font = new System.Drawing.Font("Times New Roman", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.siticoneButton10.ForeColor = System.Drawing.Color.White;
            this.siticoneButton10.Location = new System.Drawing.Point(256, 599);
            this.siticoneButton10.Name = "siticoneButton10";
            this.siticoneButton10.Size = new System.Drawing.Size(85, 36);
            this.siticoneButton10.TabIndex = 146;
            this.siticoneButton10.Text = "0";
            this.siticoneButton10.Click += new System.EventHandler(this.siticoneButton10_Click);
            // 
            // nine
            // 
            this.nine.BorderRadius = 15;
            this.nine.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.nine.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.nine.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.nine.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.nine.FillColor = System.Drawing.Color.SteelBlue;
            this.nine.Font = new System.Drawing.Font("Times New Roman", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nine.ForeColor = System.Drawing.Color.White;
            this.nine.Location = new System.Drawing.Point(347, 557);
            this.nine.Name = "nine";
            this.nine.Size = new System.Drawing.Size(85, 36);
            this.nine.TabIndex = 145;
            this.nine.Text = "9";
            this.nine.Click += new System.EventHandler(this.nine_Click);
            // 
            // eight
            // 
            this.eight.BorderRadius = 15;
            this.eight.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.eight.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.eight.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.eight.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.eight.FillColor = System.Drawing.Color.SteelBlue;
            this.eight.Font = new System.Drawing.Font("Times New Roman", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.eight.ForeColor = System.Drawing.Color.White;
            this.eight.Location = new System.Drawing.Point(256, 557);
            this.eight.Name = "eight";
            this.eight.Size = new System.Drawing.Size(85, 36);
            this.eight.TabIndex = 144;
            this.eight.Text = "8";
            this.eight.Click += new System.EventHandler(this.eight_Click);
            // 
            // seven
            // 
            this.seven.BorderRadius = 15;
            this.seven.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.seven.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.seven.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.seven.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.seven.FillColor = System.Drawing.Color.SteelBlue;
            this.seven.Font = new System.Drawing.Font("Times New Roman", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.seven.ForeColor = System.Drawing.Color.White;
            this.seven.Location = new System.Drawing.Point(165, 557);
            this.seven.Name = "seven";
            this.seven.Size = new System.Drawing.Size(85, 36);
            this.seven.TabIndex = 143;
            this.seven.Text = "7";
            this.seven.Click += new System.EventHandler(this.seven_Click);
            // 
            // six
            // 
            this.six.BorderRadius = 15;
            this.six.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.six.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.six.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.six.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.six.FillColor = System.Drawing.Color.SteelBlue;
            this.six.Font = new System.Drawing.Font("Times New Roman", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.six.ForeColor = System.Drawing.Color.White;
            this.six.Location = new System.Drawing.Point(347, 515);
            this.six.Name = "six";
            this.six.Size = new System.Drawing.Size(85, 36);
            this.six.TabIndex = 142;
            this.six.Text = "6";
            this.six.Click += new System.EventHandler(this.six_Click);
            // 
            // five
            // 
            this.five.BorderRadius = 15;
            this.five.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.five.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.five.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.five.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.five.FillColor = System.Drawing.Color.SteelBlue;
            this.five.Font = new System.Drawing.Font("Times New Roman", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.five.ForeColor = System.Drawing.Color.White;
            this.five.Location = new System.Drawing.Point(256, 515);
            this.five.Name = "five";
            this.five.Size = new System.Drawing.Size(85, 36);
            this.five.TabIndex = 141;
            this.five.Text = "5";
            this.five.Click += new System.EventHandler(this.five_Click);
            // 
            // four
            // 
            this.four.BorderRadius = 15;
            this.four.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.four.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.four.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.four.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.four.FillColor = System.Drawing.Color.SteelBlue;
            this.four.Font = new System.Drawing.Font("Times New Roman", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.four.ForeColor = System.Drawing.Color.White;
            this.four.Location = new System.Drawing.Point(165, 515);
            this.four.Name = "four";
            this.four.Size = new System.Drawing.Size(85, 36);
            this.four.TabIndex = 140;
            this.four.Text = "4";
            this.four.Click += new System.EventHandler(this.four_Click);
            // 
            // three
            // 
            this.three.BorderRadius = 15;
            this.three.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.three.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.three.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.three.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.three.FillColor = System.Drawing.Color.SteelBlue;
            this.three.Font = new System.Drawing.Font("Times New Roman", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.three.ForeColor = System.Drawing.Color.White;
            this.three.Location = new System.Drawing.Point(347, 473);
            this.three.Name = "three";
            this.three.Size = new System.Drawing.Size(85, 36);
            this.three.TabIndex = 139;
            this.three.Text = "3";
            this.three.Click += new System.EventHandler(this.three_Click);
            // 
            // two
            // 
            this.two.BorderRadius = 15;
            this.two.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.two.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.two.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.two.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.two.FillColor = System.Drawing.Color.SteelBlue;
            this.two.Font = new System.Drawing.Font("Times New Roman", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.two.ForeColor = System.Drawing.Color.White;
            this.two.Location = new System.Drawing.Point(256, 473);
            this.two.Name = "two";
            this.two.Size = new System.Drawing.Size(85, 36);
            this.two.TabIndex = 138;
            this.two.Text = "2";
            this.two.Click += new System.EventHandler(this.two_Click);
            // 
            // one
            // 
            this.one.BorderRadius = 15;
            this.one.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.one.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.one.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.one.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.one.FillColor = System.Drawing.Color.SteelBlue;
            this.one.Font = new System.Drawing.Font("Times New Roman", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.one.ForeColor = System.Drawing.Color.White;
            this.one.Location = new System.Drawing.Point(165, 473);
            this.one.Name = "one";
            this.one.Size = new System.Drawing.Size(85, 36);
            this.one.TabIndex = 137;
            this.one.Text = "1";
            this.one.Click += new System.EventHandler(this.one_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(137, 429);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(175, 25);
            this.label5.TabIndex = 136;
            this.label5.Text = "ENTER AMOUNT:";
            // 
            // AmountText
            // 
            this.AmountText.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.AmountText.DefaultText = "";
            this.AmountText.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.AmountText.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.AmountText.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.AmountText.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.AmountText.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.AmountText.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.AmountText.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.AmountText.Location = new System.Drawing.Point(318, 429);
            this.AmountText.Name = "AmountText";
            this.AmountText.PasswordChar = '\0';
            this.AmountText.PlaceholderText = "";
            this.AmountText.SelectedText = "";
            this.AmountText.Size = new System.Drawing.Size(153, 25);
            this.AmountText.TabIndex = 135;
            this.AmountText.TextChanged += new System.EventHandler(this.AmountText_TextChanged);
            this.AmountText.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.AmountText_KeyPress);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(251, 21);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(162, 28);
            this.label1.TabIndex = 17;
            this.label1.Text = "K U M & G O ";
            this.label1.UseMnemonic = false;
            // 
            // siticoneHtmlLabel2
            // 
            this.siticoneHtmlLabel2.BackColor = System.Drawing.Color.Transparent;
            this.siticoneHtmlLabel2.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.siticoneHtmlLabel2.ForeColor = System.Drawing.Color.White;
            this.siticoneHtmlLabel2.Location = new System.Drawing.Point(186, 51);
            this.siticoneHtmlLabel2.Name = "siticoneHtmlLabel2";
            this.siticoneHtmlLabel2.Size = new System.Drawing.Size(314, 30);
            this.siticoneHtmlLabel2.TabIndex = 18;
            this.siticoneHtmlLabel2.Text = "G A S O L I N E S T A T I O N";
            // 
            // siticonePictureBox2
            // 
            this.siticonePictureBox2.BackColor = System.Drawing.Color.Transparent;
            this.siticonePictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("siticonePictureBox2.Image")));
            this.siticonePictureBox2.ImageRotate = 0F;
            this.siticonePictureBox2.Location = new System.Drawing.Point(572, 1);
            this.siticonePictureBox2.Name = "siticonePictureBox2";
            this.siticonePictureBox2.Size = new System.Drawing.Size(22, 28);
            this.siticonePictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.siticonePictureBox2.TabIndex = 149;
            this.siticonePictureBox2.TabStop = false;
            this.siticonePictureBox2.UseTransparentBackground = true;
            this.siticonePictureBox2.Click += new System.EventHandler(this.siticonePictureBox2_Click);
            // 
            // MenuForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(44)))), ((int)(((byte)(51)))));
            this.ClientSize = new System.Drawing.Size(598, 658);
            this.Controls.Add(this.siticonePictureBox2);
            this.Controls.Add(this.siticoneButton15);
            this.Controls.Add(this.Clear);
            this.Controls.Add(this.siticoneButton10);
            this.Controls.Add(this.nine);
            this.Controls.Add(this.eight);
            this.Controls.Add(this.seven);
            this.Controls.Add(this.six);
            this.Controls.Add(this.five);
            this.Controls.Add(this.four);
            this.Controls.Add(this.three);
            this.Controls.Add(this.two);
            this.Controls.Add(this.one);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.AmountText);
            this.Controls.Add(this.siticonePictureBox1);
            this.Controls.Add(this.siticoneButton3);
            this.Controls.Add(this.siticoneButton2);
            this.Controls.Add(this.siticoneButton1);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.siticonePanel3);
            this.Controls.Add(this.siticonePanel2);
            this.Controls.Add(this.siticonePanel1);
            this.Controls.Add(this.siticoneHtmlLabel2);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "MenuForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "MenuForm";
            ((System.ComponentModel.ISupportInitialize)(this.siticonePictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.siticonePictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Siticone.Desktop.UI.WinForms.SiticonePictureBox siticonePictureBox1;
        private Siticone.Desktop.UI.WinForms.SiticoneButton siticoneButton3;
        private Siticone.Desktop.UI.WinForms.SiticoneButton siticoneButton2;
        private Siticone.Desktop.UI.WinForms.SiticoneButton siticoneButton1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private Siticone.Desktop.UI.WinForms.SiticonePanel siticonePanel3;
        private Siticone.Desktop.UI.WinForms.SiticonePanel siticonePanel2;
        private Siticone.Desktop.UI.WinForms.SiticonePanel siticonePanel1;
        private Siticone.Desktop.UI.WinForms.SiticoneButton siticoneButton15;
        private Siticone.Desktop.UI.WinForms.SiticoneButton Clear;
        private Siticone.Desktop.UI.WinForms.SiticoneButton siticoneButton10;
        private Siticone.Desktop.UI.WinForms.SiticoneButton nine;
        private Siticone.Desktop.UI.WinForms.SiticoneButton eight;
        private Siticone.Desktop.UI.WinForms.SiticoneButton seven;
        private Siticone.Desktop.UI.WinForms.SiticoneButton six;
        private Siticone.Desktop.UI.WinForms.SiticoneButton five;
        private Siticone.Desktop.UI.WinForms.SiticoneButton four;
        private Siticone.Desktop.UI.WinForms.SiticoneButton three;
        private Siticone.Desktop.UI.WinForms.SiticoneButton two;
        private Siticone.Desktop.UI.WinForms.SiticoneButton one;
        private System.Windows.Forms.Label label5;
        private Siticone.Desktop.UI.WinForms.SiticoneTextBox AmountText;
        private System.Windows.Forms.Label label1;
        private Siticone.Desktop.UI.WinForms.SiticoneHtmlLabel siticoneHtmlLabel2;
        private Siticone.Desktop.UI.WinForms.SiticonePictureBox siticonePictureBox2;
    }
}