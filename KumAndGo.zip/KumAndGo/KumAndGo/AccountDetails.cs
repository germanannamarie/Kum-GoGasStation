﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KumAndGo
{
    public partial class AccountDetails : Form
    {
        public AccountDetails()
        {
            InitializeComponent();
        }

        private void AccountDetails_Load(object sender, EventArgs e)
        {
            cash.Text = GlobalVariable.variable_cash;
        }

        private void siticoneButton15_Click(object sender, EventArgs e)
        {
            int c = Int32.Parse(GlobalVariable.variable_amount);
            int d = Int32.Parse(GlobalVariable.variable_cash);



            if (d < c)
            {
                MessageBox.Show("Insuficcient Funds", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);

                this.Hide();
                Form1 f3 = new Form1();
                f3.ShowDialog();
            }
            else
            {
                this.Hide();
                DeductionForm f3 = new DeductionForm();
                f3.ShowDialog();
            }
        }

        private void cash_Click(object sender, EventArgs e)
        {

        }
    }
}
