﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KumAndGo
{
    public partial class InventoryForm : Form
    {
        public InventoryForm()
        {
            InitializeComponent();
        }

        private void InventoryForm_Load(object sender, EventArgs e)
        {
            int l = Int32.Parse(GlobalVariable.variable_liters);
            int d = Int32.Parse(GlobalVariable.variable_Dliters);
            int p = Int32.Parse(GlobalVariable.variable_Pliters);
            int u = Int32.Parse(GlobalVariable.variable_Uliters);
            int total = 0;

            if (GlobalVariable.variable_Fuel == "Premium")
            {
                total = d - l;
                diesel.Text = total.ToString();
                GlobalVariable.variable_Dliters = total.ToString();
            }
            else if (GlobalVariable.variable_Fuel == "Unleaded")
            {
                total = p - l;
                premium.Text = total.ToString();
                GlobalVariable.variable_Pliters = total.ToString();

            }
            else if (GlobalVariable.variable_Fuel == "Diesel")
            {
                total = u - l;
                unleaded.Text = total.ToString();
                GlobalVariable.variable_Uliters = total.ToString();

            }
        }

        private void siticoneButton4_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 form = new Form1();
            form.ShowDialog();
        }
    }
}
