﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KumAndGo
{
    public partial class BalanceForm : Form
    {
        public BalanceForm()
        {
            InitializeComponent();
        }

        private void siticoneButton15_Click(object sender, EventArgs e)
        {
            string box_msg = "Please wait to fill your fuel!";
            MessageBox.Show(box_msg, "", MessageBoxButtons.OK, MessageBoxIcon.Information);
            this.Hide();
            FillingUp f3 = new FillingUp();
            f3.ShowDialog();
        }

        private void BalanceForm_Load(object sender, EventArgs e)
        {
            int c = Int32.Parse(GlobalVariable.variable_amount);
            int d = Int32.Parse(GlobalVariable.variable_cash);
            int a = d - c;
            string change = Convert.ToString(a);

            GlobalVariable.variable_change = change;
            cash.Text = change;

        }
    }
}
