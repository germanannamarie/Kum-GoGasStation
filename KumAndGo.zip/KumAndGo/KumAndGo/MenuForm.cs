﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace KumAndGo
{
    public partial class MenuForm : Form
    {
        double number;

        public MenuForm()
        {
            InitializeComponent();
        }
        public static class GlobalVar
        {
            public static string fuel;
        }

        private void siticoneButton2_Click(object sender, EventArgs e)
        {
            GlobalVar.fuel = "Unleaded";
        }

        private void siticoneButton1_Click(object sender, EventArgs e)
        {
            GlobalVar.fuel = "Premium";
        }

        private void siticonePictureBox2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void siticoneButton3_Click(object sender, EventArgs e)
        {
            GlobalVar.fuel = "Diesel";
        }

        private void one_Click(object sender, EventArgs e)
        {
            number = 1;
            AmountText.Text += number;
        }

        private void two_Click(object sender, EventArgs e)
        {
            number = 2;
            AmountText.Text += number;
        }

        private void three_Click(object sender, EventArgs e)
        {
            number = 3;
            AmountText.Text += number;
        }

        private void four_Click(object sender, EventArgs e)
        {
            number = 4;
            AmountText.Text += number;
        }

        private void five_Click(object sender, EventArgs e)
        {
            number = 5;
            AmountText.Text += number;
        }

        private void six_Click(object sender, EventArgs e)
        {
            number = 6;
            AmountText.Text += number;
        }

        private void seven_Click(object sender, EventArgs e)
        {
            number = 7;
            AmountText.Text += number;
        }

        private void eight_Click(object sender, EventArgs e)
        {
            number = 8;
            AmountText.Text += number;
        }

        private void nine_Click(object sender, EventArgs e)
        {
            number = 0;
            AmountText.Text += number;
        }

        private void siticoneButton10_Click(object sender, EventArgs e)
        {
            number = 0;
            AmountText.Text += number;
        }

        private void Clear_Click(object sender, EventArgs e)
        {
            AmountText.Text = "";
        }

        private void siticoneButton15_Click(object sender, EventArgs e)
        {
            GlobalVariable.variable_Fuel = GlobalVar.fuel;
            GlobalVariable.variable_amount = AmountText.Text;


            if (GlobalVar.fuel != null)
            {
                string box_msg = "FUEL TYPE: " + GlobalVar.fuel + Environment.NewLine + "AMOUNT: " + GlobalVariable.variable_amount;
                MessageBox.Show(box_msg, "INFORMATION", MessageBoxButtons.OK, MessageBoxIcon.Information);

                this.Hide();
                PIN f3 = new PIN();
                f3.ShowDialog();
            }

            else if (GlobalVar.fuel == null)
            {
                string box_msg1 = "PLEASE CHOOSE FUEL TYPE!";
                MessageBox.Show(box_msg1, "", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }

        }

        private void AmountText_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void AmountText_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;

            if (!Char.IsDigit(ch) && ch != 8 && ch != 46);
            {
                e.Handled = true;
            }
        }
    }
}
