﻿namespace KumAndGo
{
    partial class PIN
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label3 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label4 = new System.Windows.Forms.Label();
            this.PinNum = new Siticone.Desktop.UI.WinForms.SiticoneTextBox();
            this.Enter = new Siticone.Desktop.UI.WinForms.SiticoneButton();
            this.Cancel = new Siticone.Desktop.UI.WinForms.SiticoneButton();
            this.Clear = new Siticone.Desktop.UI.WinForms.SiticoneButton();
            this.zero = new Siticone.Desktop.UI.WinForms.SiticoneButton();
            this.nine = new Siticone.Desktop.UI.WinForms.SiticoneButton();
            this.eight = new Siticone.Desktop.UI.WinForms.SiticoneButton();
            this.seven = new Siticone.Desktop.UI.WinForms.SiticoneButton();
            this.six = new Siticone.Desktop.UI.WinForms.SiticoneButton();
            this.five = new Siticone.Desktop.UI.WinForms.SiticoneButton();
            this.four = new Siticone.Desktop.UI.WinForms.SiticoneButton();
            this.three = new Siticone.Desktop.UI.WinForms.SiticoneButton();
            this.two = new Siticone.Desktop.UI.WinForms.SiticoneButton();
            this.one = new Siticone.Desktop.UI.WinForms.SiticoneButton();
            this.siticoneHScrollBar1 = new Siticone.Desktop.UI.WinForms.SiticoneHScrollBar();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(15, 24);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(201, 16);
            this.label3.TabIndex = 38;
            this.label3.Text = "Swipe your card here ---->>>>>";
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.LightGray;
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.PinNum);
            this.groupBox1.Controls.Add(this.Enter);
            this.groupBox1.Controls.Add(this.Cancel);
            this.groupBox1.Controls.Add(this.Clear);
            this.groupBox1.Controls.Add(this.zero);
            this.groupBox1.Controls.Add(this.nine);
            this.groupBox1.Controls.Add(this.eight);
            this.groupBox1.Controls.Add(this.seven);
            this.groupBox1.Controls.Add(this.six);
            this.groupBox1.Controls.Add(this.five);
            this.groupBox1.Controls.Add(this.four);
            this.groupBox1.Controls.Add(this.three);
            this.groupBox1.Controls.Add(this.two);
            this.groupBox1.Controls.Add(this.one);
            this.groupBox1.Location = new System.Drawing.Point(67, 102);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(305, 315);
            this.groupBox1.TabIndex = 37;
            this.groupBox1.TabStop = false;
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(65, 16);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(190, 22);
            this.label4.TabIndex = 36;
            this.label4.Text = "Enter your Card PIN";
            // 
            // PinNum
            // 
            this.PinNum.BackColor = System.Drawing.Color.Silver;
            this.PinNum.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.PinNum.DefaultText = "";
            this.PinNum.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.PinNum.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.PinNum.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.PinNum.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.PinNum.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.PinNum.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.PinNum.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.PinNum.Location = new System.Drawing.Point(69, 41);
            this.PinNum.Name = "PinNum";
            this.PinNum.PasswordChar = '*';
            this.PinNum.PlaceholderText = "";
            this.PinNum.SelectedText = "";
            this.PinNum.Size = new System.Drawing.Size(182, 36);
            this.PinNum.TabIndex = 42;
            this.PinNum.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.PinNum.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.PinNum_KeyPress);
            // 
            // Enter
            // 
            this.Enter.BorderRadius = 15;
            this.Enter.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.Enter.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.Enter.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.Enter.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.Enter.FillColor = System.Drawing.Color.SeaGreen;
            this.Enter.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Enter.ForeColor = System.Drawing.Color.White;
            this.Enter.Location = new System.Drawing.Point(202, 208);
            this.Enter.Name = "Enter";
            this.Enter.Size = new System.Drawing.Size(85, 36);
            this.Enter.TabIndex = 41;
            this.Enter.Text = "ENTER";
            this.Enter.Click += new System.EventHandler(this.siticoneButton1_Click);
            // 
            // Cancel
            // 
            this.Cancel.BorderRadius = 15;
            this.Cancel.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.Cancel.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.Cancel.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.Cancel.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.Cancel.FillColor = System.Drawing.Color.Red;
            this.Cancel.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Cancel.ForeColor = System.Drawing.Color.White;
            this.Cancel.Location = new System.Drawing.Point(106, 250);
            this.Cancel.Name = "Cancel";
            this.Cancel.Size = new System.Drawing.Size(95, 36);
            this.Cancel.TabIndex = 40;
            this.Cancel.Text = "CANCEL";
            this.Cancel.Click += new System.EventHandler(this.Cancel_Click);
            // 
            // Clear
            // 
            this.Clear.BorderRadius = 15;
            this.Clear.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.Clear.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.Clear.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.Clear.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.Clear.FillColor = System.Drawing.Color.Goldenrod;
            this.Clear.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Clear.ForeColor = System.Drawing.Color.White;
            this.Clear.Location = new System.Drawing.Point(20, 208);
            this.Clear.Name = "Clear";
            this.Clear.Size = new System.Drawing.Size(85, 36);
            this.Clear.TabIndex = 39;
            this.Clear.Text = "CLEAR";
            this.Clear.Click += new System.EventHandler(this.Clear_Click);
            // 
            // zero
            // 
            this.zero.BorderRadius = 15;
            this.zero.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.zero.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.zero.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.zero.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.zero.FillColor = System.Drawing.Color.Gray;
            this.zero.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.zero.ForeColor = System.Drawing.Color.White;
            this.zero.Location = new System.Drawing.Point(111, 208);
            this.zero.Name = "zero";
            this.zero.Size = new System.Drawing.Size(85, 36);
            this.zero.TabIndex = 38;
            this.zero.Text = "0";
            this.zero.Click += new System.EventHandler(this.zero_Click);
            // 
            // nine
            // 
            this.nine.BorderRadius = 15;
            this.nine.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.nine.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.nine.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.nine.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.nine.FillColor = System.Drawing.Color.Gray;
            this.nine.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nine.ForeColor = System.Drawing.Color.White;
            this.nine.Location = new System.Drawing.Point(202, 166);
            this.nine.Name = "nine";
            this.nine.Size = new System.Drawing.Size(85, 36);
            this.nine.TabIndex = 37;
            this.nine.Text = "9";
            this.nine.Click += new System.EventHandler(this.nine_Click);
            // 
            // eight
            // 
            this.eight.BorderRadius = 15;
            this.eight.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.eight.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.eight.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.eight.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.eight.FillColor = System.Drawing.Color.Gray;
            this.eight.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.eight.ForeColor = System.Drawing.Color.White;
            this.eight.Location = new System.Drawing.Point(111, 166);
            this.eight.Name = "eight";
            this.eight.Size = new System.Drawing.Size(85, 36);
            this.eight.TabIndex = 36;
            this.eight.Text = "8";
            this.eight.Click += new System.EventHandler(this.siticoneButton8_Click);
            // 
            // seven
            // 
            this.seven.BorderRadius = 15;
            this.seven.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.seven.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.seven.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.seven.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.seven.FillColor = System.Drawing.Color.Gray;
            this.seven.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.seven.ForeColor = System.Drawing.Color.White;
            this.seven.Location = new System.Drawing.Point(20, 166);
            this.seven.Name = "seven";
            this.seven.Size = new System.Drawing.Size(85, 36);
            this.seven.TabIndex = 35;
            this.seven.Text = "7";
            this.seven.Click += new System.EventHandler(this.seven_Click);
            // 
            // six
            // 
            this.six.BorderRadius = 15;
            this.six.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.six.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.six.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.six.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.six.FillColor = System.Drawing.Color.Gray;
            this.six.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.six.ForeColor = System.Drawing.Color.White;
            this.six.Location = new System.Drawing.Point(202, 124);
            this.six.Name = "six";
            this.six.Size = new System.Drawing.Size(85, 36);
            this.six.TabIndex = 34;
            this.six.Text = "6";
            this.six.Click += new System.EventHandler(this.six_Click);
            // 
            // five
            // 
            this.five.BorderRadius = 15;
            this.five.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.five.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.five.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.five.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.five.FillColor = System.Drawing.Color.Gray;
            this.five.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.five.ForeColor = System.Drawing.Color.White;
            this.five.Location = new System.Drawing.Point(111, 124);
            this.five.Name = "five";
            this.five.Size = new System.Drawing.Size(85, 36);
            this.five.TabIndex = 33;
            this.five.Text = "5";
            this.five.Click += new System.EventHandler(this.siticoneButton5_Click);
            // 
            // four
            // 
            this.four.BorderRadius = 15;
            this.four.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.four.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.four.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.four.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.four.FillColor = System.Drawing.Color.Gray;
            this.four.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.four.ForeColor = System.Drawing.Color.White;
            this.four.Location = new System.Drawing.Point(20, 124);
            this.four.Name = "four";
            this.four.Size = new System.Drawing.Size(85, 36);
            this.four.TabIndex = 32;
            this.four.Text = "4";
            this.four.Click += new System.EventHandler(this.four_Click);
            // 
            // three
            // 
            this.three.BorderRadius = 15;
            this.three.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.three.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.three.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.three.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.three.FillColor = System.Drawing.Color.Gray;
            this.three.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.three.ForeColor = System.Drawing.Color.White;
            this.three.Location = new System.Drawing.Point(202, 83);
            this.three.Name = "three";
            this.three.Size = new System.Drawing.Size(85, 36);
            this.three.TabIndex = 31;
            this.three.Text = "3";
            this.three.Click += new System.EventHandler(this.three_Click);
            // 
            // two
            // 
            this.two.BorderRadius = 15;
            this.two.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.two.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.two.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.two.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.two.FillColor = System.Drawing.Color.Gray;
            this.two.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.two.ForeColor = System.Drawing.Color.White;
            this.two.Location = new System.Drawing.Point(111, 82);
            this.two.Name = "two";
            this.two.Size = new System.Drawing.Size(85, 36);
            this.two.TabIndex = 30;
            this.two.Text = "2";
            this.two.Click += new System.EventHandler(this.two_Click);
            // 
            // one
            // 
            this.one.BorderRadius = 15;
            this.one.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.one.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.one.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.one.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.one.FillColor = System.Drawing.Color.Gray;
            this.one.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.one.ForeColor = System.Drawing.Color.White;
            this.one.Location = new System.Drawing.Point(20, 82);
            this.one.Name = "one";
            this.one.Size = new System.Drawing.Size(85, 36);
            this.one.TabIndex = 29;
            this.one.Text = "1";
            this.one.Click += new System.EventHandler(this.one_Click);
            // 
            // siticoneHScrollBar1
            // 
            this.siticoneHScrollBar1.InUpdate = false;
            this.siticoneHScrollBar1.LargeChange = 10;
            this.siticoneHScrollBar1.Location = new System.Drawing.Point(12, 57);
            this.siticoneHScrollBar1.Name = "siticoneHScrollBar1";
            this.siticoneHScrollBar1.ScrollbarSize = 26;
            this.siticoneHScrollBar1.Size = new System.Drawing.Size(419, 26);
            this.siticoneHScrollBar1.TabIndex = 36;
            // 
            // PIN
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(155)))), ((int)(((byte)(157)))));
            this.CancelButton = this.Cancel;
            this.ClientSize = new System.Drawing.Size(447, 450);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.siticoneHScrollBar1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "PIN";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "PIN";
            this.Load += new System.EventHandler(this.PIN_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label4;
        private Siticone.Desktop.UI.WinForms.SiticoneTextBox PinNum;
        private Siticone.Desktop.UI.WinForms.SiticoneButton Enter;
        private Siticone.Desktop.UI.WinForms.SiticoneButton Cancel;
        private Siticone.Desktop.UI.WinForms.SiticoneButton Clear;
        private Siticone.Desktop.UI.WinForms.SiticoneButton zero;
        private Siticone.Desktop.UI.WinForms.SiticoneButton nine;
        private Siticone.Desktop.UI.WinForms.SiticoneButton eight;
        private Siticone.Desktop.UI.WinForms.SiticoneButton seven;
        private Siticone.Desktop.UI.WinForms.SiticoneButton six;
        private Siticone.Desktop.UI.WinForms.SiticoneButton five;
        private Siticone.Desktop.UI.WinForms.SiticoneButton four;
        private Siticone.Desktop.UI.WinForms.SiticoneButton three;
        private Siticone.Desktop.UI.WinForms.SiticoneButton two;
        private Siticone.Desktop.UI.WinForms.SiticoneButton one;
        private Siticone.Desktop.UI.WinForms.SiticoneHScrollBar siticoneHScrollBar1;
    }
}