﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KumAndGo
{
    public partial class Receipt : Form
    {
        public Receipt()
        {
            InitializeComponent();
        }

        private void Receipt_Load(object sender, EventArgs e)
        {
            fuel.Text = GlobalVariable.variable_Fuel;

            int p = 0;

            if (GlobalVariable.variable_Fuel == "Diesel")
            {
                fuelPrice.Text = "57";
                p = 57;
            }
            else if (GlobalVariable.variable_Fuel == "Premium")
            {
                fuelPrice.Text = "63";
                p = 63;
            }
            else if (GlobalVariable.variable_Fuel == "Unleaded")
            {
                fuelPrice.Text = "60";
                p = 60;
            }

            int a = Int32.Parse(GlobalVariable.variable_amount);
            int l = a / p;
            string liter = Convert.ToString(l);

            liters.Text = liter;

            GlobalVariable.variable_liters = liter;

            total.Text = GlobalVariable.variable_amount;

            cash.Text = GlobalVariable.variable_cash;
            change.Text = GlobalVariable.variable_change;
        }

        private void siticoneButton1_Click(object sender, EventArgs e)
        {
            string box_msg = "Thankyou for purchacing at KUM & GO!";
            MessageBox.Show(box_msg, "", MessageBoxButtons.OK, MessageBoxIcon.Information);

            GlobalVariable.variable_cash = GlobalVariable.variable_change;

            this.Hide();
            InventoryForm form = new InventoryForm();
            form.ShowDialog();
        }
    }
    }
