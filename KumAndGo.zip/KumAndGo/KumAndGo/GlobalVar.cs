﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KumAndGo
{
    internal class GlobalVar
    {
        internal static int amm;
    }
}
